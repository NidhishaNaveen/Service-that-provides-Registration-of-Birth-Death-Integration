from django.contrib import admin
from service.models import *
from django.contrib.auth.admin import UserAdmin
from .models import Apps

def approve_apps(modeladmin, request, queryset):
    queryset.update(is_approved=True)

approve_apps.short_description = "Approve selected apps"

class AppAdmin(admin.ModelAdmin):
    list_display = ['name','father_name','mother_name', 'age', 'phoneNo', 'application', 'place','is_approved']

    def save_model(self, request, obj, form, change):
        # Check if the is_approved checkbox is checked in the admin form
        is_approved = form.cleaned_data.get('is_approved')

        if is_approved:
            obj.is_approved = True
            obj.save()
        else:
            # If not approved, you might want to take some other action or not save at all
            # For example, you can redirect the user to a rejection page or raise an exception
            pass

admin.site.register(Apps, AppAdmin)

class BirthAdmin(admin.ModelAdmin):
    list_display=('first_name', 'lastname', 'gender', 'date_of_birth', 'father_name', 'bloodgroup',
        'mother_name', 'email', 'phonenumber', 'add', 'place','ename','relation', 'emergencynumber')
admin.site.register(Birth, BirthAdmin)

class DeathAdmin(admin.ModelAdmin):
    list_display=('first_name', 'lastname', 'gender', 'date_of_birth', 'father_name', 'bloodgroup',
        'mother_name', 'email', 'phonenumber', 'add', 'place','ename','relation', 'emergencynumber')
admin.site.register(Death, DeathAdmin)

class ContactAdmin(admin.ModelAdmin):
    list_display=('username', 'email', 'add')
admin.site.register(Contact, ContactAdmin)

class FeedAdmin(admin.ModelAdmin):
    list_display=('name', 'email', 'msg')
admin.site.register(Feed, FeedAdmin)
    
# Register your models here.