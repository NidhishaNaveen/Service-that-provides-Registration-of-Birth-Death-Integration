from django.db import models
from django.contrib.auth.models import User


class Apps(models.Model):
    name = models.CharField(max_length=255)
    father_name = models.CharField(max_length=255)
    mother_name = models.CharField(max_length=255)
    age = models.IntegerField()
    phoneNo = models.CharField(max_length=15)
    application = models.CharField(max_length=255)
    place = models.TextField()
    is_approved = models.BooleanField(default=False)

class Contact(models.Model):
    username=models.CharField(max_length=10)
    email=models.CharField(max_length=20)
    add=models.TextField()

class Birth(models.Model):
    first_name = models.CharField(max_length=10)
    lastname = models.CharField(max_length=10)
    gender = models.CharField(max_length=10)
    date_of_birth = models.DateField()
    father_name = models.CharField(max_length=10)
    bloodgroup = models.CharField(max_length=10)
    mother_name = models.CharField(max_length=12)
    email = models.EmailField()
    phonenumber = models.CharField(max_length=10)
    add = models.TextField()
    place = models.TextField()

    # Emergency Details
    ename = models.CharField(max_length=30)
    relation = models.CharField(max_length=30)  
    emergencynumber = models.CharField(max_length=10)

class Death(models.Model):
    first_name = models.CharField(max_length=10)
    lastname = models.CharField(max_length=10)
    gender = models.CharField(max_length=10)
    date_of_birth = models.DateField()
    father_name = models.CharField(max_length=10)
    bloodgroup = models.CharField(max_length=10)
    mother_name = models.CharField(max_length=12)
    email = models.EmailField()
    phonenumber = models.CharField(max_length=10)
    add = models.TextField()
    place = models.TextField()

    # Emergency Details
    ename = models.CharField(max_length=30)
    relation = models.CharField(max_length=30)  
    emergencynumber = models.CharField(max_length=10)

class Feed(models.Model):
    name=models.CharField(max_length=10)
    email=models.CharField(max_length=20)
    msg=models.TextField()
# Create your models here.