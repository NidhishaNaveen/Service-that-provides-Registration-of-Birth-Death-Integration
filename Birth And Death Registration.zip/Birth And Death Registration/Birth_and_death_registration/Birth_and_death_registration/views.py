from django.shortcuts import render, redirect
from django.contrib.auth.models import User
from django.contrib.auth import authenticate, login, logout
from django.http import HttpResponse
from django.contrib.auth.decorators import login_required
from service.models import *
from django.core.exceptions import ObjectDoesNotExist
from service.models import Apps

@login_required
def Home(request):
    return render(request,'Home.html', {})

def Register(request):
    if request.method == 'POST':
        name = request.POST.get('username')
        email = request.POST.get('email')
        phno = request.POST.get('number')
        password = request.POST.get('password')

        new_user = User.objects.create_user(name, email, password)
        new_user.phno = phno

        new_user.save()
        return redirect('loginpage')
    return render(request,'Register.html', {})

def Login(request):
    if request.method == 'POST':
        name = request.POST.get('username')
        password = request.POST.get('password')

        user = authenticate(request, username=name, password=password)
        if user is not None:
            login(request, user)
            return redirect('home')
        else:
            return HttpResponse('Error, user does not exist')
    return render(request,'Login.html', {})

def logoutuser(request):
    logout(request)
    return redirect('loginpage')

def Aboutus(request):
    return render(request,'Aboutus.html', {})

def Services(request):
    return render(request,'Services.html', {})

def Contactus(request):
    if request.method == "POST":
        username = request.POST['username']
        email = request.POST['email']
        messages = request.POST['add']
        ins = Contact(username=username,add=messages, email=email)
        ins.save()
        print("ok")
    return render(request,'Contactus.html', {})

def Birthde(request):
    if request.method == "POST":
        first_name = request.POST['first_name']
        lastname = request.POST['lastname']
        gender = request.POST['gender']
        date_of_birth = request.POST['date_of_birth']
        father_name = request.POST['father_name']
        bloodgroup = request.POST['bloodgroup']
        mother_name = request.POST['mother_name']
        email = request.POST['email']
        phonenumber = request.POST['phonenumber']
        add = request.POST['add']
        place = request.POST['place']
        ename = request.POST['ename']
        relation = request.POST['relation']
        emergencynumber = request.POST['emergencynumber']
        ins = Birth(first_name=first_name, lastname=lastname, gender=gender, date_of_birth=date_of_birth, father_name=father_name, bloodgroup=bloodgroup, mother_name=mother_name, email=email, phonenumber=phonenumber, add=add, place=place, ename=ename, relation=relation, emergencynumber=emergencynumber)
        ins.save()
        print("ok")
    return render(request,'Birth.html', {})

def Deathde(request):
    if request.method == "POST":
        first_name = request.POST['first_name']
        lastname = request.POST['lastname']
        gender = request.POST['gender']
        date_of_birth = request.POST['date_of_birth']
        father_name = request.POST['father_name']
        bloodgroup = request.POST['bloodgroup']
        mother_name = request.POST['mother_name']
        email = request.POST['email']
        phonenumber = request.POST['phonenumber']
        add = request.POST['add']
        place = request.POST['place']
        ename = request.POST['ename']
        relation = request.POST['relation']
        emergencynumber = request.POST['emergencynumber']
        ins = Death(first_name=first_name, lastname=lastname, gender=gender, date_of_birth=date_of_birth, father_name=father_name, bloodgroup=bloodgroup, mother_name=mother_name, email=email, phonenumber=phonenumber, add=add, place=place, ename=ename, relation=relation, emergencynumber=emergencynumber)
        ins.save()
        print("ok")
    return render(request,'Death.html', {})

def Appointmentdetails(request):
    if request.method == 'POST':
        name = request.POST.get('name')
        father_name = request.POST.get('father_name')
        mother_name = request.POST.get('mother_name')
        age = request.POST.get('age')
        phoneNo = request.POST.get('phoneNo')
        application = request.POST.get('application')
        place = request.POST.get('place')

        new_appointment = Apps.objects.create(
            name=name,
            father_name=father_name,
            mother_name=mother_name,
            age=age,
            phoneNo=phoneNo,
            application=application,
            place=place
        )

        # You can add additional logic here if needed

        return redirect('appointment')
    return render(request, 'Appointment.html', {})

def Priscription(request):
    # Fetch only approved appointments
    approved_appointments = Apps.objects.filter(is_approved=True)

    context = {'approved_appointments': approved_appointments}
    return render(request, 'Priscription.html', context)

def Feedback(request):
    if request.method == "POST":
        name = request.POST['name']
        email = request.POST['email']
        messages = request.POST['msg']
        ins = Feed(name=name,msg=messages, email=email)
        ins.save()
        print("ok")
    return render(request,'Feedback.html', {})
